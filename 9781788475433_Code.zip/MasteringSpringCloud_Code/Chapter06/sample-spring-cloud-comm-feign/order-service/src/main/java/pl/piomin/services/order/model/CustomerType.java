package pl.piomin.services.order.model;

public enum CustomerType {

	NEW, REGULAR, VIP;
	
}
