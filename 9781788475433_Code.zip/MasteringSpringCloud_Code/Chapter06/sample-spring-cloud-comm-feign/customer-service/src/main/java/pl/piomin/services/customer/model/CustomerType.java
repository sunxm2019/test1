package pl.piomin.services.customer.model;

public enum CustomerType {

	NEW, REGULAR, VIP;
	
}
